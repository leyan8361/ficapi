package com.fic.service.service;


import com.fic.service.Vo.ResponseVo;

public interface MovieService {

    ResponseVo getMovieInfo();
}
